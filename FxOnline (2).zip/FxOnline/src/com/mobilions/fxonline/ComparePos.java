package com.mobilions.fxonline;
import java.util.Comparator;

public class ComparePos implements Comparator<TabRow>{

	public int compare(TabRow o1, TabRow o2) {
		if(o1.pos1>o2.pos1)
			return 1;
		else if(o1.pos1<o2.pos1)
			return -1;
		else

			
		return 0;
	}
	
}
