package com.mobilions.fxonline;

import android.view.View;
import android.widget.AdapterView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemSelectedListener;

public class DropdownListener  implements OnItemSelectedListener {

	
	@Override
	public void onItemSelected(AdapterView<?> parent, View view,
            int pos, long id) {
        /*parent.getItemAtPosition(pos);
        Toast.makeText(parent.getContext(),
        		"ItemSelected" + parent.getItemAtPosition(pos).toString(),
        		Toast.LENGTH_SHORT).show();*/
		String item = parent.getItemAtPosition(pos).toString();
		
	      Toast.makeText(parent.getContext(), "Selected: " + item, Toast.LENGTH_LONG).show();
          
    }

    public void onNothingSelected(AdapterView<?> parent) {
        // Another interface callback
    }

}
